from flask import Flask, jsonify
app = Flask(__name__)

@app.route('/start-gen/<uuid>')
def start(uuid):
    open(f'/projects/{uuid}/var1.obj', 'w').close()
    open(f'/projects/{uuid}/var2.obj', 'w').close()
    open(f'/projects/{uuid}/var3.obj', 'w').close()
    return jsonify(success=True) # генерация началась

@app.route('/get-status/<uuid>')
def get_status(uuid):
    #return jsonify(state='ready') # генерация завершена, модель сохранена в /projects/<uuid>/result.ifc
    #return jsonify(state='error', message='Описание ошибки') # произошла ошибка
    return jsonify(state='process') # идёт генерация

if __name__ == '__main__':
    app.run(host='0.0.0.0')